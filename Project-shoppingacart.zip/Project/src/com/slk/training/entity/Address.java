package com.slk.training.entity;

public class Address {

	private String username;
	private String fullname;
	private String mobileno;
	private int pincode;
	private String area;
	private String city;
	private String state;
	
	public Address() {
		// TODO Auto-generated constructor stub
	}

	public Address(String username, String fullname, String mobileno, int pincode, String area, String city,
			String state) {
		super();
		this.username = username;
		this.fullname = fullname;
		this.mobileno = mobileno;
		this.pincode = pincode;
		this.area = area;
		this.city = city;
		this.state = state;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
	
}
