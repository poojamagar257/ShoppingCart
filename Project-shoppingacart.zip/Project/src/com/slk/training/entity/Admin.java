package com.slk.training.entity;

public class Admin {

	private String adminName;
	private String adminPassword;
	private String email;
	private int contactNo;
	
	public Admin() {
	}

	public Admin(String adminName, String adminPassword, String email, int contactNo) {
		this.adminName = adminName;
		this.adminPassword = adminPassword;
		this.email = email;
		this.contactNo = contactNo;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminPassword() {
		return adminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		this.adminPassword = adminPassword;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getContactNo() {
		return contactNo;
	}

	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}

	
}
