package com.slk.training.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.slk.training.dao.AdminManager;

@WebServlet({ "/AdminLoginServlet", "/admin-login" })
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/pages/admin-login.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		String adminName = request.getParameter("adminName");
		String adminPassword = request.getParameter("adminPassword");

		if (AdminManager.validate(adminName, adminPassword)) {
//			RequestDispatcher rs = request.getRequestDispatcher("/WEB-INF/pages/product-form.jsp");
//			rs.forward(request, response);
			response.sendRedirect("./add-new-product");
		} else {

			RequestDispatcher rs = request.getRequestDispatcher("/WEB-INF/pages/home.jsp");
			rs.forward(request, response);
		}
	}

}
