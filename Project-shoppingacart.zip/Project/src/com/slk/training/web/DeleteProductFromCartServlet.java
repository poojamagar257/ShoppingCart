package com.slk.training.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.slk.training.dao.CartManager;


@WebServlet({ "/DeleteProductFromCartServlet", "/delete-from-cart" })
public class DeleteProductFromCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String input;
        input= request.getParameter("id");
        HttpSession session = request.getSession();

		
		String username =(String) session.getAttribute("username");
		
		CartManager cm = new CartManager();
		
        cm.deleteProduct(Integer.parseInt(input),username);
		response.sendRedirect("./get-cart-products");

	}

	
}
