package com.slk.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.slk.training.entity.User;

public class UserManager {
	
	private static Connection openConnection() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		String url= "jdbc:mysql://localhost/myproject";
		String user="root";
		String password="root";
		return DriverManager.getConnection(url, user, password);
	}
	
	public void addNewUser(User u){
		String sql = "insert into users values(?,?,?,?)";
		
		try(
			Connection conn = openConnection();
			PreparedStatement stmt = conn.prepareStatement(sql) 
			){
			
			stmt.setString(1, u.getUsername());
			stmt.setString(2, u.getPassword());
			stmt.setString(3, u.getEmail());
			stmt.setInt(4, u.getContact());
			
			
			stmt.executeUpdate();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static  boolean validate(String username, String password){
		boolean status = false;
		String sql ="select * from users where username=? and password=? ";
		try(
				Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql) 
				){
				
				stmt.setString(1, username);
				stmt.setString(2, password);
				ResultSet rs=stmt.executeQuery(); 
				status=rs.next();  
				
			}
			catch(Exception ex){
				ex.printStackTrace();
			}
		return status;
	}

	

}
