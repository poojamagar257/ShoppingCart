package com.slk.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.slk.training.entity.Address;


public class AddressManager {

	private static Connection openConnection() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		String url= "jdbc:mysql://localhost/myproject";
		String user="root";
		String password="root";
		return DriverManager.getConnection(url, user, password);
	}
	public Address getAddressbyUsername(String username) {
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement("select * from address where username = ?");

		) {
			stmt.setString(1, username);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				Address a = new Address();
				a.setUsername(rs.getString("username"));
				a.setFullname(rs.getString("fullname"));
				a.setMobileno(rs.getString("mobileno"));
				a.setPincode(rs.getInt("pincode"));
				a.setArea(rs.getString("area"));
				a.setCity(rs.getString("city"));
				a.setState(rs.getString("state"));
				return a;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
	
	public void addDeliveryAddress(Address a){
		String sql = "insert into address values(?,?,?,?,?,?,?)";
		
		try(
			Connection conn = openConnection();
			PreparedStatement stmt = conn.prepareStatement(sql) 
			){
			
			stmt.setString(1, a.getUsername());
			stmt.setString(2,a.getFullname());
			stmt.setString(3, a.getMobileno());
			stmt.setInt(4, a.getPincode());
			stmt.setString(5,a.getArea());
			stmt.setString(6, a.getCity());
			stmt.setString(7,a.getState());
			
			stmt.executeUpdate();
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
}
