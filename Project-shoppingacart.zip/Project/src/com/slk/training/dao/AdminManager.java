package com.slk.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminManager {

	private static Connection openConnection() throws ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver");
		String url= "jdbc:mysql://localhost/myproject";
		String user="root";
		String password="root";
		return DriverManager.getConnection(url, user, password);
	}
	
	public static  boolean validate(String adminName, String adminPassword){
		boolean status = false;
		String sql ="select * from admin where adminName=? and adminPassword=? ";
		try(
				Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql) 
				){
				
				stmt.setString(1, adminName);
				stmt.setString(2, adminPassword);
				ResultSet rs=stmt.executeQuery(); 
				status=rs.next();  
				
			}
			catch(Exception ex){
				ex.printStackTrace();
			}
		return status;
	}
}
