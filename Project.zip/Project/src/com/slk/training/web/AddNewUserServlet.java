package com.slk.training.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.slk.training.dao.UserManager;
import com.slk.training.entity.User;

@WebServlet({ "/AddNewUserServlet", "/add-new-user" })
public class AddNewUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	request.getRequestDispatcher("/WEB-INF/pages/register.jsp")
	.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String input;
		User u = new User();
		input = request.getParameter("username");
	    u.setUsername(input);
	    input = request.getParameter("password");
	    u.setPassword(input);
	    input = request.getParameter("email");
	    u.setEmail(input);
	    input = request.getParameter("contact");
	    u.setContact(Integer.parseInt(input));
	    
	    UserManager um = new UserManager();
	    um.addNewUser(u);
	    
	  //  response.sendRedirect("./get-all-products");
	}

}
