package com.slk.training.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.slk.training.dao.AddressManager;
import com.slk.training.entity.Address;


@WebServlet({ "/AddDeliveryAddressServlet", "/add-delivery-address" })
public class AddDeliveryAddressServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String username =(String) session.getAttribute("username");
		AddressManager am = new AddressManager();
		Address a = am.getAddressbyUsername(username);
		request.setAttribute("address", a);
		
		request.getRequestDispatcher("/WEB-INF/pages/address.jsp")
		.forward(request, response);	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String input;
		Address a = new Address();
		
		HttpSession session = request.getSession();
		String username =(String) session.getAttribute("username");
		//System.out.println(" "+username);
		
		a.setUsername(username);
		input = request.getParameter("fullname");
	    a.setFullname(input);
	    input = request.getParameter("mobileno");
	    a.setMobileno(input);
	    input = request.getParameter("pincode");
	    a.setPincode(Integer.parseInt(input));
	    input = request.getParameter("area");
	    a.setArea(input);
	    input = request.getParameter("city");
	    a.setCity(input);
	    input = request.getParameter("state");
	    a.setState(input);
	    
	    AddressManager am = new AddressManager();
	    am.addDeliveryAddress(a);
	    
	    response.sendRedirect("./payment");
	}

}
