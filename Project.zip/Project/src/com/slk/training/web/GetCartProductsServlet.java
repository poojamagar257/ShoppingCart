package com.slk.training.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.slk.training.dao.CartManager;
import com.slk.training.entity.Cart;


@WebServlet({ "/GetCartProductsServlet", "/get-cart-products" })
public class GetCartProductsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String username =(String) session.getAttribute("username");
		
		//System.out.println(" "+username);
		CartManager cm = new CartManager();
		
		
		List<Cart> list = cm.getAllProducts(username);
		request.setAttribute("cart", list);
		
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/cart.jsp");
		rd.forward(request, response);
	}


}