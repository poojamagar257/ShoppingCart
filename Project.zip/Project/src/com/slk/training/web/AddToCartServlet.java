package com.slk.training.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.slk.training.dao.CartManager;
import com.slk.training.entity.Cart;
import com.slk.training.entity.Product;


@WebServlet({ "/AddToCartServlet", "/add-to-cart" })
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int productid = Integer.parseInt(request.getParameter("productid"));
		CartManager cm = new CartManager();
		Product p = cm.getProductById(productid);
		request.setAttribute("product", p);
		
		request.getRequestDispatcher("/WEB-INF/pages/add-cart.jsp")
			.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		String input;
		Cart c = new Cart();
		
		input = request.getParameter("id");
		c.setId(Integer.parseInt(input));
		input = request.getParameter("name");
		c.setName(input);
		input = request.getParameter("category");
		c.setCategory(input);
		input = request.getParameter("price");
		c.setPrice(Double.parseDouble(input));
		input = request.getParameter("quantity");

		c.setQuantity(Integer.parseInt(input));
		HttpSession session = request.getSession();

			
		String username =(String) session.getAttribute("username");
		c.setUsername(username);
		CartManager cm = new CartManager();
		cm.updateCart(c);

		//client-side redirection
		response.sendRedirect("./get-cart-products");

	}

}

	