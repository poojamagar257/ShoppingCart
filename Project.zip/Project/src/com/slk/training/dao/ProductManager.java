package com.slk.training.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.slk.training.entity.Product;

public class ProductManager {

	private Connection openConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost/myproject";
		String user = "root";
		String password = "root";
		return DriverManager.getConnection(url, user, password);
	}

	public void addNewProduct(Product p) {

		String sql = "insert into products  values(?,?,?,?,?)";
		try (Connection conn = openConnection(); PreparedStatement stmt = conn.prepareStatement(sql);) {

			stmt.setInt(1, p.getProductid());
			stmt.setString(2, p.getName());
			stmt.setString(3, p.getCategory());
			stmt.setDouble(4, p.getPrice());
			stmt.setInt(5, p.getQuantity());
			stmt.executeUpdate();
		} catch (Exception ex) {

			ex.printStackTrace();
		}
	}

	public List<Product> getAllProducts() {
		List<Product> list = new ArrayList<>();
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement("select * from products");
				ResultSet rs = stmt.executeQuery();) {
			while (rs.next()) {
				Product p = new Product();
				p.setProductid(rs.getInt("productid"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				p.setQuantity(rs.getInt("quantity"));
				list.add(p);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return list;
	}

	public void updateProduct(Product p) {
		String sql = "update products set name=?, category=?, price=? , quantity= ? where productid=?";
		try (Connection conn = openConnection(); PreparedStatement stmt = conn.prepareStatement(sql);) {

			stmt.setString(1, p.getName());
			stmt.setString(2, p.getCategory());
			stmt.setDouble(3, p.getPrice());
			stmt.setInt(4, p.getQuantity());
			stmt.setInt(5, p.getProductid());

			stmt.executeUpdate();
		} catch (Exception ex) {
			// this is wrong; exception must be propogated to the presentation
			// layer
			ex.printStackTrace();
		}
	}

	public Product getProductById(int id) {
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement("select * from products where productid = ?");

		) {
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			if (rs.next()) {
				Product p = new Product();
				p.setProductid(rs.getInt("productid"));
				p.setName(rs.getString("name"));
				p.setCategory(rs.getString("category"));
				p.setPrice(rs.getDouble("price"));
				p.setQuantity(rs.getInt("quantity"));
				return p;
			}
		} catch (Exception ex) {
			ex.printStackTrace(); // this is wrong! should propagate the
									// exceptions to the UI layer
		}
		return null;
	}

	public void updateProductQuantity(String username){
		String sql= "update products join cart on products.productid=cart.id  set products.quantity=(products.quantity)-(cart.quantity) where cart.username=?";
		try (Connection conn = openConnection();
				PreparedStatement stmt = conn.prepareStatement(sql);)
		{
			stmt.setString(1, username);
			stmt.executeUpdate();
				
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
